package com.example.amartyabanerjee.bluetoothapplication;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.UUID;

public class btConnect extends AppCompatActivity {

    private static final String TAG = "btConnect";

    Button SEND;
    TextView date;
    TextView textView1;

    BluetoothAdapter myBluetooth;
    BluetoothSocket btSocket;
    String Address = null;
    String Receive;
    private int mState;
    private int mNewState;
    private static final String APP_NAME = "BT APP";
    static final UUID myUUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");
    private boolean isBtConnected = false;
    private OutputStream outputStream;
    private InputStream inputStream;
    private ProgressDialog progress;
    SendReceive sendReceive;
    ArrayList<String> stringArrayList =new ArrayList<String>();
    ArrayAdapter<String>arrayAdapter;
    static final int STATE_LISTENING = 1;
    static final int STATE_CONNECTING = 2;
    static final int STATE_CONNECTED = 3;
    static final int STATE_CONNECTION_FAILED = 4;
    static final int STATE_MESSAGE = 5;
    int REQUEST_ENABLE_BLUETOOTH = 1;
    TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bt_connect);
        final TextView date = (TextView) findViewById(R.id.textView);
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yy'-'HH:mm:ss':'");
        String cuurentdateandtime = sdf.format(calendar.getTime());
        date.setText(cuurentdateandtime);
        Intent newint = getIntent();
        Address = newint.getStringExtra(MainActivity.EXTRA_ADDRESS);
        SEND = (Button) findViewById(R.id.button4);
        textView2 = (TextView) findViewById(R.id.editText);
        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd.MM.yy':'HH:mm:ss'-'");
        String cuurentdateandtime1 = sdf.format(calendar.getTime());
        textView2.setText(cuurentdateandtime1);
        textView1=(TextView) findViewById(R.id.textView3);
        myBluetooth = BluetoothAdapter.getDefaultAdapter();
        new ConnectBT().execute();


        SEND.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        String string = String.valueOf(textView2.getText());
                                        sendReceive.write(string.getBytes());
                                    }
                                }
        );
    //   sendReceive.run();



    }





   /* private void send() {
        String string=String.valueOf(date.getText());
        try {
            outputStream.write(string.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/

    public void message(String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
    }

    private class ConnectBT extends AsyncTask<Void, Void, Void> {
        private boolean ConnectSuccess = true;

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                if (btSocket == null || !isBtConnected) {
                    myBluetooth = BluetoothAdapter.getDefaultAdapter();
                    BluetoothDevice dispositivo = myBluetooth.getRemoteDevice(Address);
                    btSocket = dispositivo.createInsecureRfcommSocketToServiceRecord(myUUID);
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    btSocket.connect();
                }
            } catch (IOException e) {
                ConnectSuccess = false;
            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            progress = ProgressDialog.show(btConnect.this, "connecting....", "Please Wait!!");

        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            if (!ConnectSuccess) {
                message("connection failed");
                finish();
            } else {
                message("connected");
                sendReceive=new SendReceive(btSocket);
                sendReceive.start();
                isBtConnected = true;
            }
            progress.dismiss();
        }
    }

/*    public btConnect(Context context, Handler handler) {
        myBluetooth = BluetoothAdapter.getDefaultAdapter();
        mState = STATE_NONE;
        mNewState = mState;
        Handler = handler;
    }

    private void connectionLost() {
        // Send a failure message back to the Activity
        Message msg = mHandler.obtainMessage(SyncStateContract.Constants.MESSAGE_TOAST);
        Bundle bundle= new Bundle();
        bundle.putString(SyncStateContract.Constants., "Device connection was lost");
        msg.setData(bundle);
        mHandler.sendMessage(msg);

        mState = STATE_NONE;
        // Update UI title
        updateUserInterfaceTitle();

        // Start the service over to restart listening mode
        btConnect.this.start();
    }
  private  class connectedThread extends Thread {
      public connectedThread(BluetoothSocket socket, String socketType) {
          Log.d(TAG, "create Connected Thread:" + socketType);
          InputStream tmpin = null;
          OutputStream tmpout = null;
          try {
              tmpin = socket.getInputStream();
              tmpout = socket.getOutputStream();
          } catch (IOException e) {
              Log.e(TAG, "temp socket not created", e);
          }
          mState = STATE_CONNECTED;
      }

      public void run() {
          Log.i(TAG, "BEGIN mconnectedThread");
          byte[] buffer = new byte[1024];
          int bytes;
          while (mState == STATE_CONNECTED) {
              try {
                  bytes = inputStream.read(buffer);
                  handler.obtainMessage(SyncStateContract.Constants.MESSAGE_READ, bytes, -1, buffer)
                          .sendToTarget();

              } catch (IOException e) {
                  Log.e(TAG, "Disconnect", e);
                  connectionLost();
                  break;
              }
          }
      }

      public void write(byte[] buffer) {
          try {
              outputStream.write(buffer);

              // Share the sent message back to the UI Activity
              handler.obtainMessage(SyncStateContract.Constants.MESSAGE_WRITE, -1, -1, buffer)
                      .sendToTarget();
          } catch (IOException e) {
              Log.e(TAG, "Exception during write", e);
          }
      }

      public void cancel() {
          try {
              btSocket.close();
          } catch (IOException e) {
              Log.e(TAG, "close() of connect socket failed", e);
          }
      }
  }
*/
Handler handler =new Handler(){
    @Override
    public void handleMessage(Message msg) {
        byte[] writeBuf = (byte[]) msg.obj;
        int begin = (int)msg.arg1;
        int end = (int)msg.arg2;

        switch(msg.what) {
            case STATE_MESSAGE:

                byte[] readBuff = (byte[]) msg.obj;
                String tempmsg = new String(readBuff, 0, msg.arg1);
                int x = tempmsg.length();
                System.out.println(x);
                if (x > 4) {
                    textView1.append(tempmsg);
                    break;
                } else {
                    break;
                }
        }
    }
};
   /* Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what) {
                case STATE_LISTENING:
                    //textView.setText("listening");
                    break;
                case STATE_CONNECTING:
                    progress = ProgressDialog.show(btConnect.this, "connecting....", "Please Wait!!");
                    //textView.setText("connecting");
                    break;
                case STATE_CONNECTED:
                    message("connected");
                    //textView.setText("connected");
                    break;
                case STATE_CONNECTION_FAILED:
                    message("connection failed");
                    break;
                case STATE_MESSAGE:

                    byte[] readBuff = (byte[]) msg.obj;
                    String tempmsg = new String(readBuff,0,msg.arg1);
                    System.out.println(tempmsg);
                     textView1.append(tempmsg);
                    break;
            }

            return true;
        }
    });

    *//*private class AcceptThread extends Thread {

        private BluetoothServerSocket serverSocket;

        public AcceptThread() {
            // Use a temporary object that is later assigned to mmServerSocket
            // because mmServerSocket is final.
            try {
                // MY_UUID is the app's UUID string, also used by the client code.
                serverSocket = myBluetooth.listenUsingRfcommWithServiceRecord(APP_NAME, myUUID);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run() {
            BluetoothSocket socket = null;
            // Keep listening until exception occurs or a socket is returned.
            while (socket == null) {
                try {
                    Message message = Message.obtain();
                    message.what = STATE_CONNECTING;
                    handler.sendMessage(message);
                    socket = serverSocket.accept();
                } catch (IOException e) {

                    e.printStackTrace();
                    Message message = Message.obtain();
                    message.what = STATE_CONNECTION_FAILED;
                    handler.sendMessage(message);

                }


                if (socket != null) {
                    // A connection was accepted. Perform work associated with
                    // the connection in a separate thread.
                    Message message = Message.obtain();
                    message.what = STATE_CONNECTED;
                    handler.sendMessage(message);
                    sendReceive = new SendReceive(socket);
                    sendReceive.start();
                    break;
                }
            }
        }


    }

    private  class Clientclass extends Thread{
        private BluetoothDevice device;
        private  BluetoothSocket socket;
        public Clientclass(BluetoothDevice device){
            this.device=device;
            try{
                socket=device.createRfcommSocketToServiceRecord(myUUID);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        public  void run(){
            try {
                socket.connect();
                Message message= Message.obtain();
                message.what=STATE_CONNECTED;
                handler.sendMessage(message);
                sendReceive=new SendReceive(socket);
                sendReceive.start();
            } catch (IOException e) {
                e.printStackTrace();
                Message message= Message.obtain();
                message.what=STATE_CONNECTION_FAILED;
                handler.
            }
        }
    }*/
    private class SendReceive extends Thread{

   public SendReceive(BluetoothSocket socket){
    btSocket= socket;
    InputStream tmpin=null;
    OutputStream tempout=null;

    try {
        tmpin=btSocket.getInputStream();
        tempout=btSocket.getOutputStream();
    } catch (IOException e) {
        e.printStackTrace();
    }
   inputStream=tmpin;
    outputStream=tempout;

}
  /* public void run() {
            byte[] buffer = new byte[1024];
            int begin = 0;
            int bytes = 0;
            while (true) {
                try {
                    bytes += inputStream.read(buffer, bytes, buffer.length - bytes);
                    for(int i = begin; i < bytes; i++) {
                         {
                            handler.obtainMessage(1, begin, i, buffer).sendToTarget();
                            begin = i + 1;
                            if(i == bytes - 1) {
                                bytes = 0;
                                begin = 0;
                            }
                        }
                    }
                } catch (IOException e) {
                    break;
                }
            }
        }*/
public void  run(){
    byte []buffer = new byte[256];
    int bytes;
    int begin =0;
    while(true){
        try {
            bytes = inputStream.read(buffer);

            handler.obtainMessage(STATE_MESSAGE, bytes, -1, buffer).sendToTarget();


        } catch (IOException e) {
            Log.e(TAG,"ERROR HAPPENS",e);
            e.printStackTrace();
        }
    }
}
private void write (byte[] bytes){
    try {
        outputStream.write(bytes);
    } catch (IOException e) {
        e.printStackTrace();
    }
}
}
 /*   private TextView.OnEditorActionListener mWriteListener
            = new TextView.OnEditorActionListener() {
        public boolean onEditorAction(TextView view, int actionId, KeyEvent event) {
            // If the action is a key-up event on the return key, send the message
            if (actionId == EditorInfo.IME_NULL && event.getAction() == KeyEvent.ACTION_UP) {
                String message = textView1.getText().toString();
                sendReceive.run();
            }
            return true;
        }
    };*/
  /*  public static class MyBluetoothService {
        private static final String TAG = "MY_APP_DEBUG_TAG";
        private Handler handler; // handler that gets info from Bluetooth service

        // Defines several constants used when transmitting messages between the
        // service and the UI.
        private interface MessageConstants {
            public static final int MESSAGE_READ = 0;
            public static final int MESSAGE_WRITE = 1;
            public static final int MESSAGE_TOAST = 2;

            // ... (Add other message types here as needed.)
        }

        private class ConnectedThread extends Thread {
            private final BluetoothSocket mmSocket;
            private final InputStream mmInStream;
            private final OutputStream mmOutStream;
            private byte[] mmBuffer; // mmBuffer store for the stream

            public ConnectedThread(BluetoothSocket socket) {
                mmSocket = socket;
                InputStream tmpIn = null;
                OutputStream tmpOut = null;

                // Get the input and output streams; using temp objects because
                // member streams are final.
                try {
                    tmpIn = socket.getInputStream();
                } catch (IOException e) {
                    Log.e(TAG, "Error occurred when creating input stream", e);
                }
                try {
                    tmpOut = socket.getOutputStream();
                } catch (IOException e) {
                    Log.e(TAG, "Error occurred when creating output stream", e);
                }

                mmInStream = tmpIn;
                mmOutStream = tmpOut;
            }

            public void run() {
                mmBuffer = new byte[1024];
                int numBytes; // bytes returned from read()

                // Keep listening to the InputStream until an exception occurs.
                while (true) {
                    try {
                        // Read from the InputStream.
                        numBytes = mmInStream.read(mmBuffer);
                        // Send the obtained bytes to the UI activity.
                        Message readMsg = handler.obtainMessage(
                                MessageConstants.MESSAGE_READ, numBytes, -1,
                                mmBuffer);
                        readMsg.sendToTarget();
                    } catch (IOException e) {
                        Log.d(TAG, "Input stream was disconnected", e);
                        break;
                    }
                }
            }

            // Call this from the main activity to send data to the remote device.
             void write(byte[] bytes) {
                try {
                    mmOutStream.write(bytes);

                    // Share the sent message with the UI activity.
                    Message writtenMsg = handler.obtainMessage(
                            MessageConstants.MESSAGE_WRITE, -1, -1, mmBuffer);
                    writtenMsg.sendToTarget();
                } catch (IOException e) {
                    Log.e(TAG, "Error occurred when sending data", e);

                    // Send a failure message back to the activity.
                    Message writeErrorMsg =
                            handler.obtainMessage(MessageConstants.MESSAGE_TOAST);
                    Bundle bundle = new Bundle();
                    bundle.putString("toast",
                            "Couldn't send data to the other device");
                    writeErrorMsg.setData(bundle);
                    handler.sendMessage(writeErrorMsg);
                }
            }

            // Call this method from the main activity to shut down the connection.
            public void cancel() {
                try {
                    mmSocket.close();
                } catch (IOException e) {
                    Log.e(TAG, "Could not close the connect socket", e);
                }
            }
        }
    }

*/



}



